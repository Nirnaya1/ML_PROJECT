from flask import Flask, render_template, request, redirect, url_for
import joblib
import numpy as np

diabetes_model=joblib.load('/home/nirnaya/Desktop/ML/ML_Project/static/diabetes_model.pkl')
cvd_model=joblib.load('/home/nirnaya/Desktop/ML/ML_Project/static/cvd_model.pkl')
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        age = int(request.form.get('age'))
        gender = int(request.form.get('gender'))
        height= int(request.form.get('height'))
        weight = float(request.form.get('weight'))
        blood_glucose_level = float(request.form.get('blood_glucose_level'))
        if blood_glucose_level<=140:
            cvd_gluc=1
        elif blood_glucose_level<=200:
            cvd_gluc=2
        else:
            cvd_gluc=3
        cholestrol = float(request.form.get('cholestrol'))
        hba1c = float(request.form.get('hba1c'))
        bp_h = float(request.form.get('bp_h'))
        bp_l = float(request.form.get('bp_l'))
        exercise = int(request.form.get('exercise'))
        hypertension = int(request.form.get('hypertension'))
        smoke = int(request.form.get('smoke'))
        alcohol = int(request.form.get('alcohol'))
        # Simulate model processing
        bmi=float(weight/(height/100)**2)
        cvd_features=np.array([age,height,weight,bp_h,bp_l,cholestrol,cvd_gluc,smoke,alcohol,exercise])
        cvd_output=cvd_model.predict(cvd_features.reshape(1,-1))
        diabeties_features=np.array([gender,age,hypertension,cvd_output[0],smoke,bmi,hba1c,blood_glucose_level])
        diabetes_output=diabetes_model.predict(diabeties_features.reshape(1,-1))
        print()
        if cvd_output==0:
            cvd_risk ="low"
        else: 
            cvd_risk="high"
        if diabetes_output==0:
            diabetes_risk ="low"
        else: 
            diabetes_risk="high"

        result = f"Risk of Heart Disease: {cvd_risk} <br> Risk of diabetes :{diabetes_risk}"  # Reverse input as example
        return redirect(url_for('output', result=result))
    return render_template('form.html')

@app.route('/output', methods=['GET'])
def output():
    result = request.args.get('result', 'No result provided')
    return render_template('output.html', result=result)

if __name__ == '__main__':
    app.run(debug=True,port=5001)
